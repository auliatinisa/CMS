<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon inbox"></i><span class="break"></span>Tanggapan</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						<p><b>*click Email utk membalas Pesan<b></p>  
						  <thead>
							  <tr>
								  <th>No</th>
								  <th>Nama</th>
								  <th>Email</th>
								  			  
								  <th>Pesan</th>
							  </tr>
						  </thead>   
						  <tbody>
							<tr>
								<td>1</td>
								<td class="center">adsd</td>
								<td class="center">user</td>
								<td class="center">Masditrs</td>
								
								
								
							</tr>
							<tr>
								<td>2</td>
								<td class="center">adsd</td>
								<td class="center">user</td>
								<td class="center">Masditrs</td>
								
								
								
								
							</tr>
							<tr>
								<td>3</td>
								<td class="center">adsd</td>
								<td class="center">user</td>
								<td class="center">Masditrs</td>
								
								
								
							</tr>
							
						  </tbody>
					  </table>   
					     
					</div>
				</div><!--/span-->
			
			</div><!--/row-->
			<!--JANGAN DIHAPUS TAG DIV DIBAWAH-->
</div><!--/.fluid-container-->
<!-- end: Content -->
</div><!--/#content.span10-->
</div><!--/fluid-row-->
<!--JANGAN DIHAPUS TAG DIV DIATAS-->
