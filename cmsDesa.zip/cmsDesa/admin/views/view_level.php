<div class="row-fluid sortable">		
				<div class="box span11">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon user"></i><span class="break"></span>Members</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>No</th>
								  <th>Username</th>
								  <th>Level</th>
								  <th>Nama Lengkap</th>
								  <th>Email</th>
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
							<tr>
								<td>1</td>
								<td class="center">adsd</td>
								<td class="center">user</td>
								<td class="center">Masditrs</td>
								<td class="center">mn@gm.com</td>
								<td class="center">
									<a class="btn btn-info" href="edit-user.html"> Edit
										<i class="halflings-icon white edit"></i>  
									</a>
									<a class="btn btn-danger" href="#"> Hapus
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
							<tr>
								<td>2</td>
								<td class="center">adsd</td>
								<td class="center">user</td>
								<td class="center">Masditrs</td>
								<td class="center">mn@gm.com</td>
								<td class="center">
									<a class="btn btn-info" href="edit-user.html"> Edit
										<i class="halflings-icon white edit"></i>  
									</a>
									<a class="btn btn-danger" href="#"> Hapus
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
							<tr>
								<td>3</td>
								<td class="center">adsd</td>
								<td class="center">user</td>
								<td class="center">Masditrs</td>
								<td class="center">mn@gm.com</td>
								<td class="center">
									<a class="btn btn-info" href="edit-user.html"> Edit
										<i class="halflings-icon white edit"></i>  
									</a>
									<a class="btn btn-danger" href="#"> Hapus
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
							
						  </tbody>
					  </table>     
					  <a href="tambah-akun.html"><button type="submit" class="btn btn-success">Tambah User</button></a>       
					</div>
				</div><!--/span-->
			
			</div><!--/row-->
<!--JANGAN DIHAPUS TAG DIV DIBAWAH-->
</div><!--/.fluid-container-->
<!-- end: Content -->
</div><!--/#content.span10-->
</div><!--/fluid-row-->
<!--JANGAN DIHAPUS TAG DIV DIATAS-->