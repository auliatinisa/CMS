<?php 

	define('root', 'http://localhost/cmsdesa/');
	define('adm', 'http://localhost/cmsdesa/admin/');

?>