<?php 

	/**
	* ini adalah kumpulan fungsi untuk map
	*/
	class load_map
	{
		$query = mysql_query("select * from tbl_lokasi");
          while ($data = mysql_fetch_array($query)) {
            $lat = $data['lat'];
            $lon = $data['lng'];
            $nama = $data['nama_lokasi'];
            echo ("addMarker($lat, $lon, '<b>$nama</b>');\n");
		
	}

?>